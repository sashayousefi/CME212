Serial vs. Parallel runtimes 

General Parameters: Computer has 4 cores

Grid 1:
Parameters: dt = .001, t = 5
Parallel Time: 1.95437s
Serial Time: 3.08204s

Grid 2:
Parameters: dt = .001, t = 5
Parallel Time: 4.90714s
Serial Time: 10.2015s

Grid 3:
Parameters: dt = .0005, t = 5
Parallel Time: 36.1914s
Serial Time: 90.3591s

Grid 4:
Parameters: dt = .00005, t = .01
Parallel Time: 89.5222s
Serial Time: 191.053s 